---
name: weekly-report
description: Weekly
version: 1.0.0
---
Do it.
